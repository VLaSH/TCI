module Administrator::SettingsHelper
end
