class HomeBanner < BannerImage
end
