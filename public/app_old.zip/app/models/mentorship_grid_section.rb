class MentorshipGridSection < BannerImage
end
