class CoursePhotographyBanner < BannerImage
end
