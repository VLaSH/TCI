class CourseMultimediaBanner < BannerImage
end
