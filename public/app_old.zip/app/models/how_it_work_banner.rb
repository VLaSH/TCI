class HowItWorkBanner < BannerImage
end
