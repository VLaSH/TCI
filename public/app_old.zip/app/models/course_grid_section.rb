class CourseGridSection < BannerImage
end
