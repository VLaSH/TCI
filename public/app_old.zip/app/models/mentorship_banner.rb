class MentorshipBanner < BannerImage
end
