class TciBlogGridSection < BannerImage
end
