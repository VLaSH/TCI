class PortfolioGridSection < BannerImage
end
