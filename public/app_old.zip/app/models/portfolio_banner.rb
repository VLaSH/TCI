class PortfolioBanner < BannerImage
end
