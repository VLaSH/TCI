class WhatsNewGridSection < BannerImage
end
