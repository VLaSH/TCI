class StudentGalleryGridSection < BannerImage
end
