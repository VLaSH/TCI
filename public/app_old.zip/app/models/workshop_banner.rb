class WorkshopBanner < BannerImage
end
